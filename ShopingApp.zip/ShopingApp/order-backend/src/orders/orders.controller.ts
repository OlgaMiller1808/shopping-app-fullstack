import { Controller, Get, Post, Body } from '@nestjs/common';
import { OrdersService } from './orders.service';

@Controller('orders')
export class OrdersController {
  constructor(private readonly ordersService: OrdersService) {}

    @Get('test')
  async testConnection() {
    return this.ordersService.testConnection();
  }

  @Post()
  async saveOrder(@Body() order: any) {
    return this.ordersService.saveOrder(order);
  }
}