const fs = require('fs');
const path = require('path');

(async () => {
  try {
    const mappingPath = path.join(__dirname, 'mapping.json');
    const mapping = JSON.parse(fs.readFileSync(mappingPath, 'utf-8'));

    const response = await fetch('http://localhost:9200/orders', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(mapping),
    });

    const data = await response.json();
    console.log('Elasticsearch response:', data);
  } catch (error) {
    console.error('Error creating index:', error);
  }
})();
