import { Injectable } from '@nestjs/common';
import { Client } from '@elastic/elasticsearch';

@Injectable()
export class OrdersService {
  private readonly esClient: Client;

  constructor() {
    this.esClient = new Client({ node: 'http://localhost:9200' });
  }

   async testConnection(): Promise<any> {
    try {
      const health = await this.esClient.cluster.health();
      return {
        status: 'success',
        clusterStatus: health.status,
      };
    } catch (error) {
      return {
        status: 'error',
        message: error.message,
      };
    }
  }

  async saveOrder(order: any): Promise<any> {
    try {
      const response = await this.esClient.index({
        index: 'orders',
        body: {
          name: order.name,
          address: order.address,
          email: order.email,
          items: order.items.map(item => ({
            productId: item.id, 
            name: item.name,
            quantity: item.quantity,
            price: item.price,
          })),
          createdAt: new Date(),
        },
      });

      return {
        status: 'success',
        id: response._id,
      };
    } catch (error) {
      console.error('Failed to save order:', error);
      return {
        status: 'error',
        message: error.message,
      };
    }
  }
}
