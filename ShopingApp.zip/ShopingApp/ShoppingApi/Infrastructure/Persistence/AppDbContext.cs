﻿using Microsoft.EntityFrameworkCore;
using Domain.Entities;
using System.Collections.Generic;

namespace ShoppingApi.Infrastructure.Persistence
{
    public class AppDbContext : DbContext
    {
            public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
            {
            }

            public DbSet<Category> Categories { get; set; }
            public DbSet<Product> Products { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Product>()
                .Property(p => p.Price)
                .HasPrecision(18, 2);

            modelBuilder.Entity<Category>().HasData(
                new Category { Id = 1, Name = "Meat & Poultry" },
                new Category { Id = 2, Name = "Milk & Cheese" }
            );

            modelBuilder.Entity<Product>().HasData(
                new Product
                {
                    Id = 1,
                    Name = "Sausage",
                    Description = "Best sausage",
                    Price = 19m,
                    CategoryId = 1
                },
                new Product
                {
                    Id = 2,
                    Name = "Spring chicken",
                    Description = "Fresh Spring chicken",
                    Price = 65m,
                    CategoryId = 1
                },
                 new Product
                 {
                     Id = 3,
                     Name = "Chicken breast",
                     Description = "Fresh chicken breast",
                     Price = 50m,
                     CategoryId = 1
                 },
                new Product
                {
                    Id = 4,
                    Name = "Milk",
                    Description = "3% milk",
                    Price = 7m,
                    CategoryId = 2
                },
                new Product
                {
                    Id = 5,
                    Name = "Cottage cheese",
                    Description = "Tnuva Cottage",
                    Price = 7m,
                    CategoryId = 2
                },
                new Product
                {
                    Id = 6,
                    Name = "Sour cream",
                    Description = "Tnuva cream",
                    Price = 7m,
                    CategoryId = 2
                }
            );
        }
    }
}
