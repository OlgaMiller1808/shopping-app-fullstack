﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Application.Queries;
using Domain.Entities;
using Domain.Interfaces;
using MediatR;

namespace Application.Handlers
{
    public class GetCategoriesWithProductsHandler : IRequestHandler<GetCategoriesWithProductsQuery, IEnumerable<Category>>
    {
        private readonly ICategoryRepository _categoryRepository;

        public GetCategoriesWithProductsHandler(ICategoryRepository categoryRepository)
        {
            _categoryRepository = categoryRepository;
        }

        public async Task<IEnumerable<Category>> Handle(GetCategoriesWithProductsQuery request, CancellationToken cancellationToken)
        {
            // Assuming repository has method to get categories with products eagerly loaded
            return await _categoryRepository.GetCategoriesWithProductsAsync();
        }
    }
}
