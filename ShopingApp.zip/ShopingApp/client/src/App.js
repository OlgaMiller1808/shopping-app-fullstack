import './App.css';
import React from 'react';
import CategoryList from './components/CategoryList';
import ProductSelector from './components/ProductSelector';
import Cart from './components/Cart';
import { Routes, Route } from 'react-router-dom';
import OrderForm from './components/OrderForm';

function App() {
  return (
    <div style={{ padding: '20px' }}>
      <div className="container">
        <h1>Shopping App</h1>

        <Routes>
          <Route
            path="/"
            element={
              <>
                <CategoryList />
                <ProductSelector />
                <Cart />
              </>
            }
          />
          <Route path="/order" element={<OrderForm />} />
        </Routes>
      </div>
    </div>
  );
}

export default App;
