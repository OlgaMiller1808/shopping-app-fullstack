import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { submitOrder } from '../actions/orderActions';

const OrderSummary = () => {
  const dispatch = useDispatch();
  const cartItems = useSelector((state) => state.cart.cartItems);

  const [form, setForm] = useState({
    fullName: '',
    address: '',
    email: '',
  });

  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!form.fullName || !form.address || !form.email) {
      alert('Please fill in all required fields');
      return;
    }

    dispatch(submitOrder({ ...form, items: cartItems }));
    setSubmitted(true);
  };

  if (submitted) return <h3>Order submitted successfully!</h3>;

  return (
    <div>
      <h2>Order Summary</h2>

      <form onSubmit={handleSubmit}>
        <div>
          <label>Full Name:</label>
          <input name="fullName" value={form.fullName} onChange={handleChange} required />
        </div>

        <div>
          <label>Address:</label>
          <input name="address" value={form.address} onChange={handleChange} required />
        </div>

        <div>
          <label>Email:</label>
          <input name="email" type="email" value={form.email} onChange={handleChange} required />
        </div>

        <h4>Cart Items</h4>
        <ul>
          {cartItems.map((item) => (
            <li key={item.id}>
              {item.name} x {item.quantity} = ${item.price * item.quantity}
            </li>
          ))}
        </ul>

        <button type="submit">Confirm Order</button>
      </form>
    </div>
  );
};

export default OrderSummary;
