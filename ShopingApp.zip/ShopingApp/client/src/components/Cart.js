import React from 'react';
import { useSelector, useDispatch  } from 'react-redux';
import { removeFromCart, updateCartQuantity } from '../actions/cartActions';
import { useNavigate } from 'react-router-dom';

const Cart = () => {
    const dispatch = useDispatch();
    const cartItems = useSelector((state) => state.cart.cartItems);

    const totalPrice = (cartItems || []).reduce(
    (sum, item) => sum + item.quantity * item.price,
    0
  );

  const handleRemove = (id) => {
    dispatch(removeFromCart(id));
  };

  const handleQuantityChange = (id, newQuantity) => {
    const qty = parseInt(newQuantity);
    if (!isNaN(qty) && qty >= 0) {
      dispatch(updateCartQuantity(id, qty));
    }
  };

  const navigate = useNavigate();

    const handleCheckout = () => {
    navigate('/order'); 
  };

  return (
    <div>
      <h3>Your Cart</h3>
      {cartItems.length === 0 ? (
        <p>Cart is empty.</p>
      ) : (
        <ul>
          {cartItems.map((item) => (
            <li key={item.id} className="cart-item">
              <span>{item.name}</span>
              <input
                type="number"
                value={item.quantity}
                min="0"
                onChange={(e) => handleQuantityChange(item.id, e.target.value)}
              />
              <span>${item.price * item.quantity}</span>
              <button onClick={() => handleRemove(item.id)}>Remove</button>
            </li>
          ))}
           {cartItems.length > 0 && (
                <button onClick={handleCheckout}>
                Proceed to Checkout
                </button>
      )}
        </ul>
      )}
      <div className="total">Total: ${totalPrice.toFixed(2)}</div>
    </div>
  );
};

export default Cart;
