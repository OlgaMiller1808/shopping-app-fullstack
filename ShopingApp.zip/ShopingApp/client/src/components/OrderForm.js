import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { submitOrder } from '../actions/orderActions';

const OrderForm = () => {
  const dispatch = useDispatch();
  const cartItems = useSelector((state) => state.cart.cartItems);
  const orderState = useSelector((state) => state.order);

  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [email, setEmail] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!name || !address || !email) {
      alert('Please fill in all fields');
      return;
    }

    const orderData = {
      name,
      address,
      email,
      items: cartItems,
    };

    dispatch(submitOrder(orderData));
  };

  useEffect(() => {
    if (orderState.success) {
      setName('');
      setAddress('');
      setEmail('');
    }
  }, [orderState.success]);

  return (
    <div>
      <h3>Order Summary</h3>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Full Name:</label>
          <input value={name} onChange={(e) => setName(e.target.value)} required />
        </div>
        <div>
          <label>Address:</label>
          <input value={address} onChange={(e) => setAddress(e.target.value)} required />
        </div>
        <div>
          <label>Email:</label>
          <input value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>

        <h4>Items:</h4>
        <ul>
          {cartItems.map((item) => (
            <li key={item.id}>
              {item.name} - Qty: {item.quantity} - ${item.price}
            </li>
          ))}
        </ul>

        <button type="submit" disabled={orderState.loading}>
          {orderState.loading ? 'Submitting...' : 'Submit Order'}
        </button>
      </form>

      {orderState.loading && <p>Sending order...</p>}
      {orderState.success && <p>Order submitted successfully!</p>}
      {orderState.error && <p>Error: {orderState.error}</p>}
    </div>
  );
};

export default OrderForm;
