import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchProductsByCategory } from '../api/productApi';
import { setProducts } from '../actions/productActions';
import { addToCart } from '../actions/cartActions';

const ProductSelector = () => {
  const dispatch = useDispatch();
  const selectedCategory = useSelector(state => state.categories.selectedCategory);
  const products = useSelector(state => state.products.products);

   const [selectedProductId, setSelectedProductId] = useState('');
    const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    if (selectedCategory) {
      fetchProductsByCategory(selectedCategory)
        .then(data => dispatch(setProducts(data)))
        .catch(err => console.error('Failed to load products', err));
    }else{
        dispatch(setProducts([]));
    }
    setSelectedProductId('');
    setQuantity(1);
  }, [selectedCategory, dispatch]);

  const handleAddToCart = () => {
    const product = products.find(p => p.id === parseInt(selectedProductId));
    if (product && quantity > 0) {
      dispatch(addToCart(product, quantity));
    }
  };

  return (
       <div>
      <h3>Select Product</h3>
      <select value={selectedProductId} onChange={(e) => setSelectedProductId(e.target.value)}>
        <option value="">-- Select a product --</option>
        {products.map(product => (
          <option key={product.id} value={product.id}>{product.name}</option>
        ))}
      </select>

      <input
        type="number"
        value={quantity}
        min="1"
        onChange={(e) => setQuantity(parseInt(e.target.value))}
      />

      <button onClick={handleAddToCart} disabled={!selectedProductId}>
        Add product
      </button>
    </div>
  );
};

export default ProductSelector;
