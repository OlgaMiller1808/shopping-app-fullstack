import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchCategories } from '../api/categoryApi';
import { setCategories, setSelectedCategory } from '../actions/categoryActions';

const CategoryList = () => {
  const dispatch = useDispatch();
  const categories = useSelector((state) => state.categories.categories);
  const selectedCategory = useSelector((state) => state.categories.selectedCategory);

  useEffect(() => {
    fetchCategories()
      .then(data => dispatch(setCategories(data)))
      .catch(err => console.error('API error:', err));
  }, [dispatch]);

  const handleChange = (e) => {
    dispatch(setSelectedCategory(parseInt(e.target.value)));
  };

  return (
    <select value={selectedCategory || ''} onChange={handleChange}>
      <option value="" disabled>Select a category</option>
      {categories.map(cat => (
        <option key={cat.id} value={cat.id}>{cat.name}</option>
      ))}
    </select>
  );
};

export default CategoryList;
