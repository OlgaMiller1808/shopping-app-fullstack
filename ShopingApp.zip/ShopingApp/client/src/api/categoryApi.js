const baseUrl = 'https://localhost:7148/api/categories';

export const fetchCategories = async () => {
  const response = await fetch(baseUrl);
  if (!response.ok) {
    throw new Error('Failed to fetch categories');
  }
  return await response.json();
};

