const baseUrl  = 'https://localhost:7148/api/products';

export const fetchProducts = async () => {
  const response = await fetch(`${baseUrl}/api/products`);
  if (!response.ok) throw new Error("Failed to fetch products");
  return await response.json();
};

export async function fetchProductsByCategory(categoryId) {
  let url = baseUrl;
  if (categoryId) {
    url += `/byCategory/${categoryId}`;
  }
  
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error('Failed to fetch products');
  }
  return response.json();
}