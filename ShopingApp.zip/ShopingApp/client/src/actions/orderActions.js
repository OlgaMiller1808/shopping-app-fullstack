import { submitOrderToServer } from '../api/orderApi';

export const submitOrderRequest = () => ({
  type: 'SUBMIT_ORDER_REQUEST',
});

export const submitOrderSuccess = () => ({
  type: 'SUBMIT_ORDER_SUCCESS',
});

export const submitOrderFailure = (error) => ({
  type: 'SUBMIT_ORDER_FAILURE',
  payload: error,
});

/*export const submitOrder = (orderData) => async (dispatch) => {
  dispatch(submitOrderRequest());
  try {
    const response = await fetch('http://localhost:3001/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(orderData),
    });

    if (!response.ok) {
      throw new Error('Failed to submit order');
    }

    dispatch(submitOrderSuccess());
  } catch (error) {
    dispatch(submitOrderFailure(error.message));
  }
};*/

export const submitOrder = (orderData) => async (dispatch) => {
  dispatch({ type: 'SUBMIT_ORDER_REQUEST' });

  try {
    await submitOrderToServer(orderData);

    dispatch({ type: 'SUBMIT_ORDER_SUCCESS' });
    dispatch({ type: 'CLEAR_CART' }); 
  } catch (error) {
    dispatch({
      type: 'SUBMIT_ORDER_FAILURE',
      payload: error.message || 'Error submitting order',
    });
  }
};
