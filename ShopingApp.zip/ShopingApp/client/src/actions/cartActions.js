export const addToCart = (product, quantity) => ({
  type: 'ADD_TO_CART',
  payload: { product, quantity },
});

export const updateCartQuantity = (id, quantity) => ({
  type: 'UPDATE_CART_QUANTITY',
  payload: { id, quantity }
});

export const removeFromCart = (id) => ({
  type: 'REMOVE_FROM_CART',
  payload: id
});