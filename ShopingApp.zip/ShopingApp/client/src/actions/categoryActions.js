export const setCategories = (categories) => ({
  type: 'SET_CATEGORIES',
  payload: categories,
});

export const setSelectedCategory = (categoryId) => ({
  type: 'SET_SELECTED_CATEGORY',
  payload: categoryId,
});