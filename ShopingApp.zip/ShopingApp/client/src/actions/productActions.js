export const setSelectedCategory = (categoryId) => ({
  type: 'SET_SELECTED_CATEGORY',
  payload: categoryId,
});

export const setProducts = (products) => ({
  type: 'SET_PRODUCTS',
  payload: products,
});

export const setSelectedProduct = (productId) => ({
  type: 'SET_SELECTED_PRODUCT',
  payload: productId,
});

export const setQuantity = (qty) => ({
  type: 'SET_QUANTITY',
  payload: qty,
});