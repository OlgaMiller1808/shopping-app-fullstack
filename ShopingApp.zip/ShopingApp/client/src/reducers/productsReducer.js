const initialState = {
  selectedCategory: null,
  products: [],
  quantity: 1,
};

const productReducer = (state = initialState, action) => {
  switch (action.type) {
    case 'SET_SELECTED_CATEGORY':
      return {
        ...state,
        selectedCategory: action.payload,
      };
    case 'SET_PRODUCTS':
      return {
        ...state,
        products: action.payload,
      };
    case 'SET_SELECTED_PRODUCT':
      return { 
        ...state, 
        selectedProduct: action.payload };

    case 'SET_QUANTITY':
      return { 
        ...state, 
        quantity: action.payload };
    default:
      return state;
  }
};

export default productReducer;