const initialState = {
  loading: false,
  success: false,
  error: null,
};

const orderReducer = (state = initialState, action) => {
  switch (action.type) {
    case 'SUBMIT_ORDER_REQUEST':
      return {
        ...state,
        loading: true,
        success: false,
        error: null,
      };
    case 'SUBMIT_ORDER_SUCCESS':
      return {
        ...state,
        loading: false,
        success: true,
        error: null,
      };
    case 'SUBMIT_ORDER_FAILURE':
      return {
        ...state,
        loading: false,
        success: false,
        error: action.payload,
      };
    default:
      return state;
  }
};

export default orderReducer;
