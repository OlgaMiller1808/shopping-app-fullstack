import { combineReducers } from 'redux';
import categoryReducer from './categoryReducer';
import productReducer from './productReducer';
import orderReducer from './orderReducer';
import cartReducer from './cartReducer';

const rootReducer = combineReducers({
  categories: categoryReducer,
  products: productReducer,
  cart: cartReducer,
  order: orderReducer,

});

export default rootReducer;